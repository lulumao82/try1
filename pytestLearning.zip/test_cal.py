from Calculator.Calcu import Calculator
import pytest
import allure

class Test_cal:
    # def setup_class(self):
    #     self.cal = Calculator()
    #     print("Start testing")
    #
    # def teardown_class(self):
    #     print("End testing")

    @allure.feature("Add")
    @pytest.mark.run(order=1)
    @pytest.mark.parametrize("a,b,expected",[(1,2,3),(340,450,790),(-1,-2,-3)],
                             ids=["int","bigint","negative"])
    def test_add(self,a,b,expected,calfixture):
        result = calfixture.add(a,b)
        assert result == expected

    @allure.feature("Minus")
    @pytest.mark.parametrize("a,b,expected",[(6,2,4),(890,530,360),(-1,-5,4)],
                             ids=["int","bigint","negative"])
    def test_minus(self,a,b,expected,calfixture):
        result = calfixture.minus(a,b)
        assert result == expected

    @allure.feature("multiple")
    @pytest.mark.run(order=2)
    @pytest.mark.parametrize("a,b,expected",[(5,6,30),(250,30,7500),(-10,230,-2300)])
    def test_mul(self,a,b,expected,calfixture):
        result = calfixture.mul(a,b)
        assert result == expected

    @allure.feature("Division")
    @pytest.mark.flaky(reruns=2,reruns_delay=2)
    @pytest.mark.parametrize("a,b,expected",[(10,2,5),(300,20,12)])
    def test_div(self,a,b,expected,calfixture):
        result = calfixture.div(a,b)
        assert result == expected
