import pytest
import yaml
from Calculator.Calcu import Calculator

def get_datas():
    with open("./data.yml") as f:
        datas = yaml.safe_load(f)
        addDatas = datas["datas"]
        ids = datas["myid"]
        return [ids,addDatas]

def getlist():
   with open("./steps.yml") as f:
       contents = yaml.safe_load(f)
       return contents

   # @pytest.mark.parametrize("a,b,expected",get_datas()[0],ids=get_datas()[1])
@pytest.fixture(scope="class",params=get_datas()[1])
def myfixture(request):
    print("Test cal start")
    yield request.param
    print(request.param)

@pytest.fixture(scope="class")
def connectDB():
    print("class start")
    yield "1"
    print("class over")

@pytest.fixture(scope="session")
def fixtureSess():
    print("Session fixture")

@pytest.fixture(scope = "module")
def calfixture():
    cal = Calculator()
    print("Test Start")
    yield cal
    print("Test Over")