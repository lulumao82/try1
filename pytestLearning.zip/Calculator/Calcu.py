class Calculator:
    def add(self,a,b):
        return a+b

    def minus(self,a,b):
        return a-b

    def mul(self,a,b):
        return a*b

    def div(self,a,b):
        if b == 0:
            print("b should not be 0")
        else:
            return a/b